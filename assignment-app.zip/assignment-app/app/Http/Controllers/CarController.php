<?php

namespace App\Http\Controllers;
use App\Http\Requests\CarCreateRequest;
use App\Http\Requests\CarEditRequest;
use App\Models\Cars;
use Illuminate\Http\Request;
use App\Models\Manufacturer;

class CarController extends Controller
{
    public function destroy($id)
{
    $car = Cars::findOrFail($id);
    $car->delete();

    return redirect()->route('home')->with('success', 'Car deleted successfully.');
}

    public function edit(Cars $car){
        $manufacturers = Manufacturer::all();
        return view('car', ['car' => $car, 'success' => false, 'manufacturers' => $manufacturers]);    }

    public function update(CarEditRequest $request, Cars $car){
        
        $car->update($request->validated());
        $manufacturers = Manufacturer::all();
        return view('car', ['car' => $car, 'success' => true, 'manufacturers' => $manufacturers]);
    }

    public function show($id)
{
    $car = Cars::with('manufacturer')->findOrFail($id);
    return view('show', compact('car'));
}

public function create(){
    $manufacturers=Manufacturer::all();
    return view('create',['manufacturers' => $manufacturers,'success'=>false]);
}

public function store(CarCreateRequest $request)
    {
        $car = Cars::create($request->validated());
        $manufacturers = Manufacturer::all();
        return view('create', ['manufacturers' => $manufacturers,'success' => true]);
    }

public function search(Request $request)
    {
        $search = $request->input('search');
    
        $cars = Cars::where('model', 'like', '%'.$search.'%')
                     ->orWhereHas('manufacturer', function($query) use ($search) {
                         $query->where('name', 'like', '%'.$search.'%');
                     })
                     ->get();
    
        return view('home', compact('cars'));
    }
    

}    




