<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cars;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        if ($search) {
            $cars = Cars::where('model', 'like', "%{$search}%")
                        ->orWhereHas('manufacturer', function ($query) use ($search) {
                         $query->where('name', 'like', "%{$search}%");
                        })
                ->get();
        } else {
            $cars=Cars::with(['manufacturer'])->get();
        }

        
        
        return view('home',['cars'=>$cars]);
    }
}
