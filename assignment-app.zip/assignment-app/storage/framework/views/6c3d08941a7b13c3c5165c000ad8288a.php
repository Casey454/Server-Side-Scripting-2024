

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="d-flex justify-content-between mb-4">
        <?php if(auth()->guard()->check()): ?>
        <a href="/car" class="btn btn-primary">Add New</a>
        <?php endif; ?>
        <form class="d-flex custom-search-form" role="search" action="<?php echo e(route('cars.search')); ?>" method="GET">
            <input class="form-control me-2" type="search" name="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col">Model</th>
                <th scope="col">Year</th>
                <th scope="col">Manufacturer</th>
                <th scope="col">Sales Person Email</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($car->id); ?>">
                <th scope="row"><?php echo e($car->id); ?></th>
                <td><?php echo e($car->model); ?></td>
                <td><?php echo e($car->year); ?></td>
                <td><?php echo e($car->manufacturer->name); ?></td>
                <td><?php echo e($car->salesperson_email); ?></td>
                <td>
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('cars.edit', $car->id)); ?>" class="btn btn-secondary btn-sm">Edit</a>
                    <a href="/car/<?php echo e($car->id); ?>/show" class="btn btn-primary btn-sm">View</a>

                    
                    <form action="<?php echo e(route('cars.destroy', $car->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this car?')">Delete</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\assignment-app\resources\views/home.blade.php ENDPATH**/ ?>