

<?php $__env->startSection('title', 'Car Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Car Details</h1>
        <table class="table">
        <tr>
                <th>ID</th>
                <td><?php echo e($car->id); ?></td>
            </tr>
            <tr>
                <th>Model</th>
                <td><?php echo e($car->model); ?></td>
            </tr>
            <tr>
                <th>Year</th>
                <td><?php echo e($car->year); ?></td>
            </tr>
            <tr>
                <th>Salesperson Email</th>
                <td><?php echo e($car->salesperson_email); ?></td>
            </tr>
            <tr>
                <th>Manufacturer</th>
                <td><?php echo e($car->manufacturer->name); ?></td>
            </tr>
            <th scope="col">
            <td>
            <a href="/car/<?php echo e($car->id); ?>" 
            class="btn btn-primary btn-sm">Edit
            </a>

            <button
            onclick="deleteUser('<?php echo e($car->id); ?>')"
            type="button" class="btn btn-danger btn-sm">Delete
            </button>
            </td>
            </th>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<script>
  function deleteCar(id){
    fetch('/api/car/'+id,{
      method:'resource'
    }).then(()=>{
      document.getElementById(id).destroy();
    }).catch(e=>{

    }).finally(()=>{
   });
    }
  
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\assignment-app\resources\views/view.blade.php ENDPATH**/ ?>