<!DOCTYPE html>
<html>
    <body>
       <?php

    use \App\Models\Cars;

    $cars=Cars::with(['manufacturer'])->get();
    ?>

    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($car->model); ?> - <?php echo e($car->manufacturer->name); ?></p>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </body>
</html>




<?php /**PATH C:\laragon\www\assignment-app\resources\views/welcome.blade.php ENDPATH**/ ?>