

<?php $__env->startSection('title', 'Car Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h1>Car Details</h1>
        <table class="table">
            <tr>
                <th>ID</th>
                <td><?php echo e($car->id); ?></td>
            </tr>
            <tr>
                <th>Model</th>
                <td><?php echo e($car->model); ?></td>
            </tr>
            <tr>
                <th>Year</th>
                <td><?php echo e($car->year); ?></td>
            </tr>
            <tr>
                <th>Salesperson Email</th>
                <td><?php echo e($car->salesperson_email); ?></td>
            </tr>
            <tr>
                <th>Manufacturer</th>
                <td><?php echo e($car->manufacturer->name); ?></td>
            </tr>
        </table>
        
        <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('cars.edit', $car->id)); ?>" class="btn btn-secondary">Edit</a>

       
        <form action="<?php echo e(route('cars.destroy', $car->id)); ?>" method="POST" style="display: inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this car?')">Delete</button>
        </form>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\assignment-app\resources\views/show.blade.php ENDPATH**/ ?>