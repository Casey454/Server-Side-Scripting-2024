@extends('layouts.app')

@section('title', 'Car Details')

@section('content')
    <div class="container mt-4">
        <h1>Car Details</h1>
        <table class="table">
            <tr>
                <th>ID</th>
                <td>{{ $car->id }}</td>
            </tr>
            <tr>
                <th>Model</th>
                <td>{{ $car->model }}</td>
            </tr>
            <tr>
                <th>Year</th>
                <td>{{ $car->year }}</td>
            </tr>
            <tr>
                <th>Salesperson Email</th>
                <td>{{ $car->salesperson_email }}</td>
            </tr>
            <tr>
                <th>Manufacturer</th>
                <td>{{ $car->manufacturer->name }}</td>
            </tr>
        </table>
        
        @auth
        <a href="{{ route('cars.edit', $car->id) }}" class="btn btn-secondary">Edit</a>

       
        <form action="{{ route('cars.destroy', $car->id) }}" method="POST" style="display: inline;">
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this car?')">Delete</button>
        </form>
        @endauth
    </div>
@endsection
