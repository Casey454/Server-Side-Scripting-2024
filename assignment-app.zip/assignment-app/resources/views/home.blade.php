@extends('layouts.app')

@section('content')

<div class="container mt-4">
    <div class="d-flex justify-content-between mb-4">
        @auth
        <a href="/car" class="btn btn-primary">Add New</a>
        @endauth
        <form class="d-flex custom-search-form" role="search" action="{{ route('cars.search') }}" method="GET">
            <input class="form-control me-2" type="search" name="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col">Model</th>
                <th scope="col">Year</th>
                <th scope="col">Manufacturer</th>
                <th scope="col">Sales Person Email</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            @foreach($cars as $car)
            <tr id="{{ $car->id }}">
                <th scope="row">{{ $car->id }}</th>
                <td>{{ $car->model }}</td>
                <td>{{ $car->year }}</td>
                <td>{{ $car->manufacturer->name }}</td>
                <td>{{ $car->salesperson_email }}</td>
                <td>
                    @auth
                    <a href="{{ route('cars.edit', $car->id) }}" class="btn btn-secondary btn-sm">Edit</a>
                    <a href="/car/{{ $car->id }}/show" class="btn btn-primary btn-sm">View</a>

                    
                    <form action="{{ route('cars.destroy', $car->id) }}" method="POST" style="display: inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this car?')">Delete</button>
                    </form>
                    @endauth
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

@endsection
