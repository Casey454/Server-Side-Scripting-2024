@extends('layouts.app')

@section('content')

    <table class="table">
        <thead>
            <tr>
                <th scope="col"></th>
                <th scope="col">Model</th>
                <th scope="col">Year</th>
                <th scope="col">Manufacturer</th>
                <th scope="col">Sales Person Email</th>
                <th scope="col"></th>
            </tr>
        </thead>
        <tbody>
            @foreach($cars as $car)
            <tr id="{{ $car->id }}">
                <th scope="row">{{ $car->id }}</th>
                <td>{{ $car->model }}</td>
                <td>{{ $car->year }}</td>
                <td>{{ $car->manufacturer->name }}</td>
                <td>{{ $car->salesperson_email }}</td>
                <td>
                    
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

@endsection
