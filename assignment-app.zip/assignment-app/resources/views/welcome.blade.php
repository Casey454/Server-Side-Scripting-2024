<!DOCTYPE html>
<html>
    <body>
       <?php

    use \App\Models\Cars;

    $cars=Cars::with(['manufacturer'])->get();
    ?>

    @foreach ($cars as $car )
        <p>{{$car->model}} - {{$car->manufacturer->name}}</p>
    
    @endforeach

    </body>
</html>




