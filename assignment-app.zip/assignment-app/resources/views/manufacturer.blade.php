@extends('layouts.app')

@section('content')
    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Address</th>
            <th scope="col">Phone</th>
        </tr>
        </thead>
     <tbody>
    @foreach($manufacturers as $manufacturer)
    <tr>
      <th scope="row">{{$manufacturer->id}}</th>
      <td>{{$manufacturer->name}}</td>
      <td>{{$manufacturer->address}}</td>
      <td>{{$manufacturer->phone}}</td>
    </tr>
    @endforeach
  </tbody>
    </table>
@endsection
