@extends('layouts.app')

@section('title', 'Add New Car')

@section('content')
    <div class="container mt-4">
        <h1>Add New Car</h1>
        <form action="/car" method="POST">
            @csrf

            <div class="mb-3">
                <label for="model" class="form-label">Model</label>
                <input type="text" class="form-control @error('model') is-invalid @enderror" id="model" name="model" value="{{ old('model') }}" required>
                @error('model')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="year" class="form-label">Year</label>
                <input type="text" class="form-control @error('year') is-invalid @enderror" id="year" name="year" value="{{ old('year') }}" required>
                @error('year')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="salesperson_email" class="form-label">Salesperson Email</label>
                <input type="email" class="form-control @error('salesperson_email') is-invalid @enderror" id="salesperson_email" name="salesperson_email" value="{{ old('salesperson_email') }}" required>
                @error('salesperson_email')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="manufacturer_id" class="form-label">Manufacturer</label>
                <select name="manufacturer_id" class="form-select @error('manufacturer_id') is-invalid @enderror" id="manufacturer_id" required>
                    <option value="">Select Manufacturer</option>
                    @foreach($manufacturers as $manufacturer)
                        <option value="{{ $manufacturer->id }}" {{ old('manufacturer_id') == $manufacturer->id ? 'selected' : '' }}>{{ $manufacturer->name }}</option>
                    @endforeach
                </select>
                @error('manufacturer_id')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>

           

            <button type="submit" class="btn btn-primary">Add Car</button>
            @if($success)
                <div class="col col-12">
                    <div class="alert alert-success my-4">
                        User was created.
                    </div>
                </div>
            @endif
        </form>
    </div>
@endsection
