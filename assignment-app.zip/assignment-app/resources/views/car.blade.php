@extends('layouts.app')

@section('title', 'Edit Car')

@section('content')
    <div class="container mt-4">
        <h1>Edit Car</h1>

        <form action="{{ route('cars.update', $car->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label for="model" class="form-label">Model</label>
                <input type="text" class="form-control @error('model') is-invalid @enderror" id="model" name="model" value="{{ old('model', $car->model) }}" required>
                @error('model')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="year" class="form-label">Year</label>
                <input type="text" class="form-control @error('year') is-invalid @enderror" id="year" name="year" value="{{ old('year', $car->year) }}" required>
                @error('year')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="salesperson_email" class="form-label">Salesperson Email</label>
                <input type="email" class="form-control @error('salesperson_email') is-invalid @enderror" id="salesperson_email" name="salesperson_email" value="{{ old('salesperson_email', $car->salesperson_email) }}" required>
                @error('salesperson_email')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>

            <div class="mb-3">
                <label for="manufacturer_id" class="form-label">Manufacturer</label>
                <select name="manufacturer_id" class="form-select @error('manufacturer_id') is-invalid @enderror" id="manufacturer_id" required>
                    @foreach($manufacturers as $manufacturer)
                        <option value="{{ $manufacturer->id }}" {{ old('manufacturer_id', $car->manufacturer_id) == $manufacturer->id ? 'selected' : '' }}>
                            {{ $manufacturer->name }}
                        </option>
                    @endforeach
                </select>
                @error('manufacturer_id')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>
            <div class="col col-12">
                <button type="submit" class="btn btn-primary">
                    Save Changes
                </button>
            </div>
            @if($success)
                <div class="col col-12">
                    <div class="alert alert-success my-4">
                        Changes were saved.
                    </div>
                </div>
            @endif
            
        </form>
    </div>
@endsection
