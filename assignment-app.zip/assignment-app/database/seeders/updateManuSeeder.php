<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class updateManuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('manufacturers')->insert([
            ['address' => 'HQ, Kyoto District, Tokyo, Japan', 'phone' => '+1 800 233 8232'],
            ['address' => '3-1 Shinchi, Fuchu-cho, Aki-gun, Hiroshima 730-8670, Japan', 'phone' => '+1 800 234 5678'],
            ['address' => '2-1-1 Minami-Aoyama, Minato-ku, Tokyo 107-8556, Japan', 'phone' => '+1 800 345 6789'],
        ]);
    }
}
