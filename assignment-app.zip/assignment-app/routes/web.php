<?php
use App\Http\Controllers\HomeController;
use App\Models\Manufacturer;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ManufacturerController;
use App\Http\Controllers\CarController;
use App\Http\Controllers\CarsController;
use App\Http\Controllers\Auth\LoginController;


//Route::get('/', function () {
//    return view('welcome');
//});

Route::get('/', [HomeController::class,'index'])->name('home');
Route::get('/manufacturer', [ManufacturerController::class,'index']);
Route::get('/cars', [CarsController::class,'index']);

Route::get('/car/{car}/show', [CarController::class,'show']);

Route::get('/car/{car}/edit', [CarController::class,'edit'])->name('cars.edit');
Route::put('/cars/{car}', [CarController::class, 'update'])->name('cars.update');
Route::delete('/cars/{car}',[CarController::class, 'destroy'])->name('cars.destroy');
Route::get('/car', [CarController::class,'create']);
Route::post('/car', [CarController::class,'store']);
Route::get('/cars/search',[CarController::class,'search'])->name('cars.search');

Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

Route::middleware(['auth'])->group(function () {
    Route::get('/cars/create', [CarController::class, 'create'])->name('cars.create');
    Route::get('/cars/{car}/edit', [CarController::class, 'edit'])->name('cars.edit');
    Route::delete('/cars/{car}', [CarController::class, 'destroy'])->name('cars.destroy');
});